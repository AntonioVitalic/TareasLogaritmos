
Compilar: $ javac -cp ".;.\lib\failureaccess-1.0.1.jar;.\lib\guava-33.2.1-jre.jar" -d bin .\src\bloom\BloomFilter.java .\src\bloom\Busqueda.java .\src\Main.java

Ejecutar: $ java -cp ".;.\lib\failureaccess-1.0.1.jar;.\lib\guava-33.2.1-jre.jar;.\bin" Main 